# Upcoming IPO and Currency rate Dashboard

Develop a responsive web and mobile application that provides authenticated users with an Upcoming IPO Calendar and the latest currency exchange rates. This project aims to demonstrate skills in API integration, user authentication, responsive design, and cross-platform development using React for web and React Native for mobile.


## Table of Contents

- [Project Overview](#project-overview)
- [Prerequisites](#prerequisites)
- [Getting Started](#getting-started)
- [Features](#features)
- [Technologies Used](#technologies-used)
- [Directory Structure](#directory-structure)
- [Installation](#installation)
- [Usage](#usage)
- [Contributing](#contributing)
- [License](#license)
- [Contact](#contact)

## Project Overview

The project is a React application that serves as a customizable dashboard for Ipo and Currency rate enthusiasts. It includes features like real-time data.


## Prerequisites

- Node.js
- npm (Node Package Manager)

## Getting Started

1. **Clone the repository:**

    ```bash
    git clone https://github.com/rohikareddy/AFSD.git
    ```

2. **Navigate to the project directory:**

    ```bash
    cd stocks-market-dashboard
    ```

3. **Install dependencies:**

    ```bash
    npm install
    ```

4. **Run the application:**

    ```bash
    npm start
    ```

    The app will be accessible at [http://localhost:3000](http://localhost:3000).

## Features

1. **Real-Time Stock Data:**
   - View stock market data, including top gainers and losers.

2. **Customizable Dashboard:**
   - Add and remove widgets to create a personalized dashboard.

3. **Interactive Charts:**
   - Visualize stock data using interactive charts like bar charts and line charts.

4. **User Authentication:**
   - Log in to access personalized features.

## Technologies Used

List the key technologies or frameworks used in your project.
- React.js
- Node.js
- Charting Libraries (e.g., Recharts, Highcharts)

## Directory Structure

- `src/`: Source code files.
- `public/`: Static assets and HTML template.

