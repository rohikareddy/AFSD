import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';
import Card from './Card';
import { useFav } from './FavContext';

const Dashboard = () =>{
    const { addToFavorites, addToHistory} = useFav();

    const [apiData, setApiData] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [recipeName, setRecipeName] = useState("walnut");


    const handleSearch = () => {
        addToHistory(recipeName);
        fetchData(recipeName);
    };


    const fetchData = async (recipeName) => {
        try {
            setLoading(true);
            const response = await fetch(`https://api.edamam.com/api/recipes/v2?type=public&app_id=582e62db&app_key=07beda73b72b13f86602bcb115347266&q=${recipeName}`);
            if (!response.ok) {
                throw new Error('Failed to fetch data');
            }
            const data = await response.json();
            setApiData(data);
        } catch (error) {
            setError(error);
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchData(recipeName);
    }, []);


    const handleAddToFavorites = (item) => {
      addToFavorites(item);
    };
    const seeMore = () => {
        console.log('Button 1 pressed');
    };


    return (
        <View style={styles.container}>
            <View style={styles.Search}>
                <TextInput
                    style={styles.input}
                    placeholder="Enter search term..."
                    value={recipeName}
                    onChangeText={text => setRecipeName(text)}
                />
                <TouchableOpacity style={styles.button} onPress={handleSearch}>
                    <Text style={styles.buttonText}>Search</Text>
                </TouchableOpacity>
            </View>
            <ScrollView>
                {apiData ? (
                    apiData.hits.map((meal, index) => (
                        <Card key={index}
                            title={meal.recipe.label.substring(0, 15)}
                            imageUrl={meal.recipe.image}
                            seeMore={seeMore}
                            handleAddToFavorites={handleAddToFavorites}
                        />
                    ))
                ) : (
                    <Text>No meals found</Text>
                )}
            </ScrollView>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
    Search: {
        flexDirection: 'row',
        alignItems: 'center',
        margin: 20,
    },
    input: {
        flex: 1,
        borderWidth: 1,
        borderColor: '#ccc',
        borderRadius: 5,
        paddingHorizontal: 10,
        marginRight: 10,
    },
    button: {
        backgroundColor: '#5dbcd2',
        paddingVertical: 10,
        paddingHorizontal: 20,
        borderRadius: 5,
    },
    buttonText: {
        color: '#fff',
        fontWeight: 'bold',
    },
});


export default Dashboard;