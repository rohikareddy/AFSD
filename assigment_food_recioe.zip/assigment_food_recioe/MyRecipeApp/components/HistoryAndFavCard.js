import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

const HistoryAndFavCard = ({ text, buttonText, onPressButton }) => {
  return (
    <View style={styles.card}>
      <View style={styles.leftContent}>
        <Text style={styles.text}>{text}</Text>
      </View>
      <View style={styles.rightContent}>
        <TouchableOpacity style={styles.button} onPress={() => onPressButton(text)}>
          <Text style={styles.buttonText}>{buttonText}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
    margin:10
  },
  leftContent: {
    flex: 1,
  },
  rightContent: {
    marginLeft: 20,
  },
  text: {
    fontSize: 16,
    fontWeight: 'bold',
    color:'black'
  },
  button: {
    backgroundColor: 'red',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});

export default HistoryAndFavCard;
