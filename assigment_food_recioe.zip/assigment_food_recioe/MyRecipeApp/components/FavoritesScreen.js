// FavoritesScreen.js
import React from 'react';
import { View, Text, Button } from 'react-native';
import { useFav } from './FavContext';
import HistoryAndFavCard from './HistoryAndFavCard';

const FavoritesScreen = () => {
  const { state, removeFromFavorites } = useFav();
  const handleRemoveFromFavorites = (item) => {
    removeFromFavorites(item);
  };
  return (
    <View>
      {state.favorites.map((favorite) => (
        <View key={favorite}>
          <HistoryAndFavCard text={favorite} buttonText={'Remove From Fav'} onPressButton={handleRemoveFromFavorites}/>
        </View>
      ))}
    </View>
  );
};

export default FavoritesScreen;
