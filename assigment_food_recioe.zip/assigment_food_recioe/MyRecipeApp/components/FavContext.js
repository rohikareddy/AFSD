// FavContext.js
import React, { createContext, useContext, useReducer } from 'react';

// Define initial state
const initialState = {
  favorites: [],
  history: [],
};

// Define actions
const ADD_TO_FAVORITES = 'ADD_TO_FAVORITES';
const REMOVE_FROM_FAVORITES = 'REMOVE_FROM_FAVORITES';
const ADD_TO_HISTORY = 'ADD_TO_HISTORY';
const REMOVE_FROM_HISTORY = 'REMOVE_FROM_HISTORY';

// Define reducer
const favReducer = (state, action) => {
  switch (action.type) {
    case ADD_TO_FAVORITES:
      // Check if the item already exists in favorites
      if (state.favorites.some(favorite => favorite === action.payload)) {
        return state; // If it exists, return the current state without adding it again
      }
      return {
        ...state,
        favorites: [...state.favorites, action.payload],
      };
    case REMOVE_FROM_FAVORITES:
      return {
        ...state,
        favorites: state.favorites.filter(favorite => favorite !== action.payload),
      };
    case ADD_TO_HISTORY:
      return {
        ...state,
        history: [...state.history, action.payload],
      };
    case REMOVE_FROM_HISTORY:
      return {
        ...state,
        history: state.history.filter(item => item !== action.payload),
      };
      case VALIDATE_USER:
      return {
        ...state,
        history: state.history.filter(item => item !== action.payload),
      };
    default:
      return state;
  }
};

// Create context
const FavContext = createContext();

// Create provider
export const FavProvider = ({ children }) => {
  const [state, dispatch] = useReducer(favReducer, initialState);

  const addToFavorites = (item) => {
    dispatch({ type: ADD_TO_FAVORITES, payload: item });
  };

  const removeFromFavorites = (item) => {
    dispatch({ type: REMOVE_FROM_FAVORITES, payload: item });
  };

  const addToHistory = (item) => {
    dispatch({ type: ADD_TO_HISTORY, payload: item });
  };

  const removeFromHistory = (item) => {
    dispatch({ type: REMOVE_FROM_HISTORY, payload: item });
  };

  const login = (email,pass) => {
    dispatch({ type: VALIDATE_USER, payload: {email:email,pass:pass} });
  };

  return (
    <FavContext.Provider value={{ state, addToFavorites, removeFromFavorites, addToHistory, removeFromHistory, login}}>
      {children}
    </FavContext.Provider>
  );
};

// Custom hook to consume context
export const useFav = () => useContext(FavContext);
