import { NavigationContainer } from '@react-navigation/native';
import React, { useState } from 'react';
import { FavProvider } from './FavContext';
import BottomTabNavigator from './BottomTabNavigator';


const TabHandler = () => {
    return (
        <NavigationContainer>
            <FavProvider>
                <BottomTabNavigator />
            </FavProvider>
        </NavigationContainer>
    );
}

export default TabHandler;