import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
// import createStackNavigator from '@'
import Login from './Login';
import Dashboard from './Dashboard'; 

const Stack = createNativeStackNavigator();

export default function StackNavigator() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Login" component={Login} />
      <Stack.Screen name="Dashboard" component={Dashboard} />
    </Stack.Navigator>
  );
}
