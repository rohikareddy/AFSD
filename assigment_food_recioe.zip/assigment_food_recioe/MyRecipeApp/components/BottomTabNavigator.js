import React, { useEffect, useState } from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import HistoryScreen from './HistoryScreen';
import FavoritesScreen from './FavoritesScreen';
import Dashboard from './Dashboard';


const Tab = createBottomTabNavigator();

const BottomTabNavigator = () => {
  const [history, setHistory] = useState([]);
  const [fav, setFav] = useState([]);

  const saveHistory = (newData) => {
    // setHistory(prevData => [...prevData, newData]);
    console.log("new data"+newData);
  };
  const saveFav = async (newData) => {
    setFav(prevData => [...prevData, newData])
    console.log("new data"+newData);
  };
  const removeHistory = () => {
    console.log('remove history');
  }

  const removeFav = () => {
    console.log('remove Fav');
  }

  return (
    <Tab.Navigator>
      <Tab.Screen name="Dashboard" component={Dashboard} />
      <Tab.Screen name="History" component={HistoryScreen} />
      <Tab.Screen name="Favorites" component={FavoritesScreen} />
    </Tab.Navigator>
  );
};

export default BottomTabNavigator;
