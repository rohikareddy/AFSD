// HistoryScreen.js
import React, { useState } from 'react';
import { View, Text, ScrollView, Button } from 'react-native';
import HistoryAndFavCard from './HistoryAndFavCard';
import { useFav } from './FavContext';


const HistoryScreen = () => {

  const { state, removeFromHistory } = useFav();

  const handleRemoveFromHistory = (item) => {
    removeFromHistory(item);
  };

  return (
    <View>
      {state.history.map((item) => (
        <View key={item}>
          <HistoryAndFavCard text={item} buttonText={'Remove From History'} onPressButton={handleRemoveFromHistory}/>
        </View>
      ))}
    </View>
  );
};

export default HistoryScreen;
