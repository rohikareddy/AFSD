import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import StackNavigator from './components/StackNavigator';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import BottomTabNavigator from './components/BottomTabNavigator';
import { FavProvider } from './components/FavContext';

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  return (
    <View>
      {isLoggedIn ? <TabHandler /> : <Login onLogin={() => setIsLoggedIn(true)} />}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    // flex: 1,
    // backgroundColor: '#fff',
    // alignItems: 'center',
    // justifyContent: 'center',
  },
});
