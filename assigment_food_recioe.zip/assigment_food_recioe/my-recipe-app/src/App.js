import './App.css';
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { AuthProvider } from "./components/AuthContext";
import AuthGuard from "./components/AuthGaurd";
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import Register from './components/Register';

function App() {
  return (
    <div className='dash-container'>
      <AuthProvider>
        <Router>
          <Routes>
            <Route path="/" exact element={<Login />} />
            <Route path="/login" element={<Login />} />
            <Route element={<AuthGuard />}>
              <Route path="/dashboard" element={<Dashboard />} />
            </Route>
            <Route path="/signup" element={<Register />} />
          </Routes>
        </Router>
      </AuthProvider>
    </div>
  );
}
export default App;
