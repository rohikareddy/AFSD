import React, { useState } from 'react'

function GetDataFromApi() {
    const [apiData,setApiData] = useState(null);
    // const [recipeName, setRecipeName] = useState("");
    const [loading,setLoading] = useState(false);
    const [error, setError] = useState(null);

    const fetchData = async (recipeName) => {
        try {
            setLoading(true);
            const response = await fetch(`https://api.edamam.com/api/recipes/v2?type=public&app_id=582e62db&app_key=07beda73b72b13f86602bcb115347266&q=${recipeName}`);
            if (!response.ok) {
                throw new Error('Failed to fetch data');
            }
            const data = await response.json();
            setApiData(data);
        } catch (error) {
            setError(error);
            console.error(error);
        }finally{
            setLoading(false);
        }
    };

  return (
    {
        apiData,
        fetchData,
        loading,
        error
    }
  )
}

export default GetDataFromApi
