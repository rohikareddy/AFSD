import React, { useState, useEffect } from 'react';
import GetDataFromApi from './GetDataFromApi';
import './Dashboard.css'
import Card from './Card';
function Dashboard() {
    const { apiData, fetchData, loading, error } = GetDataFromApi();
    const [recipeName, setRecipeName] = useState("walnut");
    const [searchHistory, setSearchHistory] = useState(() => {
        return JSON.parse(localStorage.getItem('searchHistory')) || [];
    });
    const [favorites, setFavorites] = useState(() => {
        return JSON.parse(localStorage.getItem('favorites')) || [];
    });


    const addToFavorites = (item) => {
        if (!favorites.includes(item)) {
            const updatedFavorites = [...favorites, item];
            setFavorites(updatedFavorites);
            localStorage.setItem('favorites', JSON.stringify(updatedFavorites));
        }
    };

    const removeFromFavorites = (item) => {
        const updatedFavorites = favorites.filter((fav) => fav !== item);
        setFavorites(updatedFavorites);
        localStorage.setItem('favorites', JSON.stringify(updatedFavorites));
    };

    const searchRecipe = () => {
        if (!searchHistory.includes(recipeName)) {
            const updatedHistory = [...searchHistory, recipeName];
            setSearchHistory(updatedHistory);
            localStorage.setItem('searchHistory', JSON.stringify(updatedHistory));
        }
        fetchData(recipeName);

    }

    useEffect(() => {
        fetchData(recipeName);
    }, []);

    return (
        <div className='dash-container'>
            <div className="container">
                <div className="meal-wrapper">
                    <div className="meal-search">
                        <h2 className="title">Find Meals For Your Ingredients</h2>
                        <div className="hist-fav-search">


                            <div className="search-history">
                                {searchHistory.length > 0 && (
                                    <div>
                                        <h3>Search History</h3>
                                        <ul>
                                            {searchHistory.map((item, index) => (
                                                <li key={index}>{item}</li>
                                            ))}
                                        </ul>
                                    </div>
                                )}
                            </div>
                            <div className="meal-search-box">
                                <input type="text" className="search-control" placeholder="Enter an ingredient" id="search-input" value={recipeName}
                                    onChange={(e) => setRecipeName(e.target.value)} />
                                <button type="submit" className="search-btn btn" id="search-btn" onClick={searchRecipe}>
                                    <i className="fas fa-search"></i>
                                </button>
                            </div>
                            <div className="Favroites">
                                <h3>Favorites</h3>
                                <ul>
                                    {favorites.map((item, index) => (
                                        <li key={index}>
                                            {item}
                                            <button style={{margin:'10px'}} onClick={() => removeFromFavorites(item)}>Remove</button>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div className="meal-result">
                        <h2 className="title">Your Search Results:</h2>
                        <div id="meal">
                            {/* <div> */}
                            {apiData ? (
                                apiData.hits.map((meal, index) => (
                                    <Card key={index} meal={meal} addToFav={addToFavorites} />
                                ))
                            ) : (
                                <p>No meals found</p>
                            )}
                            {/* </div> */}
                        </div>
                    </div>

                    <div className="meal-details">
                        <button type="button" className="btn recipe-close-btn" id="recipe-close-btn">
                            <i className="fas fa-times"></i>
                        </button>
                        <div className="meal-details-content">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Dashboard;
