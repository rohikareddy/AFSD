import { createContext, useContext, useState } from "react";
import { Navigate } from "react-router-dom";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [authenticated, setAuthenticated] = useState(false);

  const [registeredUsers, setRegisteredUsers] = useState([]);

  const registerUser = (userData) => {
    setRegisteredUsers((prevUsers) => [...prevUsers, userData]);
  };

  const login = (username,password) => {
    if(username.length > 0 && password.length > 0){
        if( username==='rohika' && password === 'rohika'){
          console.log(`User ${username} has logged in.`);
          setAuthenticated(true);
          <Navigate replace to="/dashboard" />
        }else{
          alert(`Please correct your username and password`);
        }
      }
       else {
        alert("Please enter a username and password.");
      }
  };

  const logout = () => {
    setAuthenticated(false);
  };

  return (
    <AuthContext.Provider
      value={{ authenticated, login, logout, registerUser, registeredUsers}}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  return useContext(AuthContext);
};
