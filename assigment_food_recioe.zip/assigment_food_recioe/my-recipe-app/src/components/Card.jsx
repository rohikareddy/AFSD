import React, { useState } from 'react'

function Card({ meal,addToFav }) {
    const [showPopup, setShowPopup] = useState(false);

    const displayDetails = () => {
        setShowPopup(!showPopup);
    };

    return (
        <div className="meal-item" >
            <div className="meal-img">
                <img src={meal.recipe.image} alt="food" />
            </div>
            <div className="meal-name">
                <h3>{meal.recipe.label.substring(0,15)}</h3>
                <button className="recipe-btn" onClick={displayDetails}>Get Recipe</button>
                <button className="recipe-btn" onClick={() => {addToFav(meal.recipe.label.substring(0,6))}}>favorite</button>
                {showPopup && <div className="popup">
                    <div className="popup-content">
                        <h2 className="recipe-title">{meal.recipe.label}</h2>
                        <p className="recipe-category">{meal.recipe.source}</p>
                        <div className="recipe-instruct">
                            <h3>Instructions:</h3>
                            <p className='ingredients'>{meal.recipe.ingredientLines.map((ing,index)=>(
                                <li key={index}>{ing}</li>
                            ))
                            }</p>
                        </div>
                        <div className="recipe-meal-img">
                            <img src={meal.strMealThumb} alt="" />
                        </div>
                        <button type="button" onClick={displayDetails}>Close</button>
                    </div>
                </div>}
            </div>
        </div>
    )
}

export default Card
